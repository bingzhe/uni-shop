
// const global = {
//   state: {
//     navindex: 0,
//     subnav: [],
//   },
//   mutations: {
//     SET_NAVINDEX: (state, navindex) => {
//       state.navindex = navindex
//     },
//     SET_SUBNAV: (state, subnav) => {
//       state.subnav = subnav
//     },
//   }
// }

// export default global
