export const ACCESS_TOKEN = 'TOKEN'
export const USER_INFO = 'USER_INFO'

export const NAV_THEME = {
  LIGHT: 'light',
  DARK: 'dark'
}