<template>
	<view class="page-wrap">
		<view class="czmain">
			<view class="cztop">
				<view class="czxx">余额充值</view>
				<view class="czyebox">
					<view class="cash-select">
						<view class="cs-title">充值方式</view>
						<template v-if="$util.isWeiXin() && !$util.isAndroid()">
							<view @click="selectType(2)" class="cs-li flex-center-y"
								v-bind:class="{ 'cs-li-select':  (payType == 2)}">
								<image src="/static/imgs/wxpay.png"
									style="height: 40rpx; width: 40rpx; margin-right: 10rpx;" mode="aspectFit"></image>
								微信支付
							</view>
							<view @click="selectType(1)" class="cs-li icon yticon flex-center-y"
								v-bind:class="{ 'cs-li-select': (payType == 1) }">
								<!-- 支付宝支付 -->
								<image src="/static/imgs/alipay.png"
									style="height: 40rpx; width: 40rpx; margin-right: 10rpx;" mode="aspectFit"></image>
								支付宝支付
							</view>
						</template>
						<template v-else>
							<view @click="selectType(1)" class="cs-li icon yticon flex-center-y"
								v-bind:class="{ 'cs-li-select': (payType == 1) }">
								<!-- 支付宝支付 -->
								<image src="/static/imgs/alipay.png"
									style="height: 40rpx; width: 40rpx; margin-right: 10rpx;" mode="aspectFit"></image>
								支付宝支付
							</view>
						</template>
					</view>
					<view class="cs-title">充值金额</view>
					<input type="digit" focus class="czye" v-model="price" @input="IntInput" />
					<view class="uni-btn-v uni-common-mt">
						<button class="onstep" @click="requestPayment(usermoney)">提交</button>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		orderBalanceCreateApi,
		orderPayApi
	} from '@/api/tuanApi.js';
	import {
		Weixin
	} from '@/static/js/wx-jssdk.js';

	const getParams = function() {
		const queryStr = location.search.substr(1);
		const arr = queryStr.split('&');
		const data = {};
		for (let key in arr) {
			let item = arr[key].split('=');
			data[item[0]] = item[1];
		}
		return data;
	}

	export default {
		data() {
			return {
				showWxPay: false, //是否显示微信支付
				loading: false,
				price: '',
				dbled: true,
				providerList: [],
				url: "",
				payType: 1, //支付方式 1支付宝，2 H5微信
				usermoney: 0,
				member_id: 0,
				wxCode: '',
				mobile: '',
				orderInfo: {
					create_time: "",
					goods_name: "",
					goods_type: "",
					order_id: "",
					order_no: "",
					order_price: "",
					relation_id: "",
					users_id: '',
				},
				payInfo: {}
			}
		},
		onLoad(option) {
			if (this.$util.isWeiXin() && !this.$util.isAndroid()) {
				this.payType = 2;
			}
		},
		onShow() {},
		methods: {
			selectType(type) {
				this.payType = type;
			},
			getWxPrePayInfo() {},
			getOrderInfo(price, usermoney) {},
			timest() {
				var tmp = Date.parse(new Date()).toString();
				tmp = tmp.substr(0, 10);
				return tmp;
			},
			IntInput(e) {
				const o = e.target;
				const inputRule = /^(0+)|[^\d]+/g //修改inputRule 的值
				this.$nextTick(function() {
					this.price = o.value.replace(inputRule, '');
				})
			},
			// 生成订单
			async orderCreate() {
				let res = await orderBalanceCreateApi({
					// goods_type: 3,
					// relation_id: '',
					price: this.price
				});
				Object.assign(this.orderInfo, res.data.data);
				// this.orderInfo = res.data.data;
			},

			async orderPay() {
				let res = await orderPayApi({
					order_no: this.orderInfo.order_no,
					pay_type: this.payType
				});
				uni.hideLoading();
				this.payInfo = res.data.data;
				if (this.payType == 1) {
					this.$util.redirectTo('/otherpages/webview/webview', {
						link: encodeURIComponent(this.payInfo.payData)
					})
					return
				}
				if (this.payType == 2) {
					WeixinJSBridge.invoke('getBrandWCPayRequest', JSON.parse(this.payInfo.payData),
						(res) => {
							uni.navigateBack({})
						})
					return;
				}

				// uni.setStorageSync('webviewUrl', this.payInfo.payData)
				// console.log(res.data)
			},
			//提交支付
			async requestPayment(usermoney) {
				console.log(this.price)
				if (!this.price) {
					this.$util.showToast({
						title: '充值金额未填'
					})
					return
				}
				if (this.price < 50) {
					this.$util.showToast({
						title: '充值金额不能小于50'
					})
					return
				}
				uni.showLoading({
					title: '支付中...',
					mask: true
				});
				await this.orderCreate();
				this.orderPay();
			},

		}
	}
</script>

<style lang="scss" scoped>
	page {
		background: #f9f9f9;
	}

	.page-wrap {
		padding-top: 30rpx;
	}

	.cash-select {
		margin: 20rpx auto 30rpx;
		overflow: hidden;
		padding: 0;
		background: #FFFFFF;
	}

	.cs-title {
		height: 80rpx;
		line-height: 80rpx;
		font-size: 34rpx;
		color: #333333;
	}

	.cs-li {
		min-height: 80rpx;
		line-height: 80rpx;
		color: #666666;
		font-size: 30rpx;
		position: relative;
	}

	.cs-li::after {
		content: '';
		position: absolute;
		width: 10rpx;
		height: 10rpx;
		background: #FFFFFF;
		border: 15rpx solid #E7E7E7;
		border-radius: 50%;
		top: 20rpx;
		right: 10rpx;
	}

	.cs-li-select::after {
		background: #FFFFFF !important;
		border: 15rpx solid #0abf1f !important;
	}

	.u-f,
	.u-f-ac,
	.u-f-ajc {
		display: flex;
	}

	.u-f-ajc {
		justify-content: center;
	}

	@font-face {
		font-family: "iconfont";
		src: url('data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAADaQAAsAAAAAZuAAADY8AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHEIGVgCQaAqBpwiBhAYBNgIkA4MkC4FUAAQgBYRtB4g0G8RTdQaY2wEEVW2/WkckTaseRdkexbP//2OCHCPG9noA+lVKlmR15EgbpA2aSuSAFJJavnQs51Ea4noWv3LjSrYilRkoWPxHa9E8/gqbvbXLDwu2iIu8wHH5OW0qzphkeS+oaPffccw8aTY7JCmaPP/8fv3WnXnfDVcJiZBJkCuUsA8BcLn7tlmga02gFBOOLJA5PD+33v9/sEpiG4M/coQIjIoVI3osoAdIlJSkwQiBYRQqw8IoQA+jAGVW4GE0KOrdeXra1wZE1GV9t+VH+nXAD/QA/iQhUqSkKZePG4PFSnluDuh/Uy0zQkLgh/VBdkYOMU6/qdt83c2VV2/48Z2pXnwZSI5dCLT8NyK0rRIEBgDRr/RLSXzHDrd8BAUcYGAwlFPVrb+7jQ8MLRtHgLZDZXeAJfDn9JW+ZEpSMMhSiExyEZxE8J9Vc050pIks0PgHIyuEKQvZhSvC5czMazv3fAAZkHvs9B9+x/vRzFpayetIuxpZuovNy3ARKoAtYCWqHezxkz944wmWUCk0XgRY7vj2+/lLbxxjtSUtiAMug5CCMLTUosg9nm8tli+1o78Qit9B2JvdJoJB+qHBEKrZ/1+X+a00hgX0TpAmhEWTdAh1mvLd9wb0pJHX0tg5kbWksRfkCYyWZTgYGDtkb8IVIM2bsXNGnoC0hIYwV06qlFilQizalGm7/8vA/yaxvQ2JgsCvuu5iAHWMuTpoDWzhIuUF6ULa6/cw5nBo7j0zbGif5Knggd/ZnoZR6+zRctfuPJHQYb5Bd/v5/aOEkHQZ0gzHQckyMtT+MjEc+l0/8Yefby9tNXoGwtj0wberX6Ri6l8pyeisBa+guqKPPejo36S1dxAO3B4eRmV3FAmdwjMpUYsn09fusGDRkiNe89BHP/noxtPgtDjtT/fT//+QzDLHYcWHnxAyUeIkSZOnVLV6LZZabpeb51UCpp2HOW74h6fJm6RIVK0is8zO19ioeebZDxzFcYzwGTLSACNdgKWswfZbeEw667h9NtrrmBNOOuW0M84574K0rJy8gqKSsoqqmrqGppa2jq6evoGhkbG1iamZuYWllY2tnb2Do5PAlJ6+zoBBQy5JOuCQLQ7aapvtho04bNSYHY6asdO8BYuWrVhll9XWWGudbY5Yb4Npc3bbY9yEWUs22UyLgXYcuj/tfH4S0wEmCQ9niQOOEwH2ERE2Egn2kggcI3k4QebhJMnHKVKA06QQZ0gRzpFinCcluEBKcZGU4TIpxxUyH1dJBa6RSlwnVbhBqnGT1OAWWYDbpBZ3SB3uknrcIw24TxrxgDThIVmIR2QRHpPFeEKW4ClpxjOiw3PSghekFS9JGz6SdrwiS/GadOAN6cRb0oV3RI/3pBsfyDJ8IsvxmazAF7ISX8kqfCOr8Z2swQ8yhEaOYoqcRI+Mok+M6Mg5DJCrGCTXMESe4BJ5g/3kDxwgX3CI/IMt5F8cJP9hK0XCNoqG7RQdwxQDI5Q5DlMcjFJWGKO8sYPyOfDpBwO9VwhgJyXFPCXDAhWFRSoOy1QiVqgkrKLSsIvSYjWVgzVULtZSeVhHFV1XwSyGwyLMEsB6qhQbqGpMU/WYo1qwm1qKPdQyjFPLMUHtxCy1C0vUTWyibj1sPtn9x3+g3Vk1BDbuAXv13vyLVzc+Z0+fiIEkhmoJ3nB8mUptS8mfIK/ZLt1lhEokuzlIu4QzrNVRL8mIaxZaNNhL1stWNAtxa9eRJHpBYUXj5twPdjeFRV8TVQZ7yfXK+hvQuBB8ZZw7mKKsreuv65ol4yalCJJYW49pfsBvHZDN5nJa55Ujqss8NqdcWKycyqGGsxnmapKESjZ3G87rMDJYJh5I7hNy6OX2ulrFm/ZqOmHD0tDUlwKwQpIxoiEbSx63kTCcbwHrKHLLgZQZayI5W0JlyOiplF2BXTREOok82TY6186jX3PuNDltYZtKEQuRK85Ym7y9arq0LPc5rDYna4mqAXIOgbkVka8IDXIigjDkjKEU50EAqQKOQjVxylBgaH8/nlOiurHivg8jaIOCGmBBDI6O9Wf+sEmE3BNWH/EbHIu+1TX80gToWd2hsiuV8IMMqz9jSmYNRxGJZx2CvKQfmrTFFwNdq+SJn1JJZENEMGIYNaX9mk/pBbpiFIiPCJLBG4jwJN6QLQCcYokmxPBK75RUl1ihLSdzqmBUaF5LOCuVw5ibACqtpZUA4gbE0/Zmi1lyQ4B5lMCEv8zlI6TqIIVV7uTyLSmRlflCYWpiQ93XyIxmCttyM4gsZxA9YBGhszCLSXIAbLTPmV5zGln3c6dWebHBfjU3BFiVujlFq2hYMbg6oIVjwYUHOP0wUj7IV1flKzV6wiNI03uQOQzMlAxhCdlTgGu22IuTWRisddvRNLJuYHT/kigVuWmdS7EUCBF1plZN+pFrDVpXFfdcZeVnmdM0DMPwmi/WrZCu4JKB8WTfCvFgNBGIDa0SHxHrNtbwAcxN0UJENLgxEJVmfLyqYlk71ZdoAbNYwlaxuqXeDjebUaNZCFIMaMubWKKDWICjUyusVQjanQUXXU7PAW6npqImq+GsoG1uOvRDuxXbO1yoRaBpug9churV3rJHQACVqcwLpW2FDUrCOU+PZf5FztGVfIH8Kr6qImJKtOeaTagpZuQrtZCBdFC57+tMrgS8ZF7Y7gbA3GszvmvTXTbMSZTfWfDtWMiLpNscTXXMFmGJSzeFqFS1xqA2B1j40YzR1OOuqOroChQE3UzE5wZGXIEO1wAwk4I0BKAlWT6c6W0BbcLAmTSfq0EAwSY8vfqLfqq91xeppZAnLD7XoeaOImB+RLVJfKoNhuqW+FfYNoIbSD5LYhjsezolM39hJXZgR/bIQBTYti8qE39bqRGnvs2oZTFGd1BzWnOK4twAX1eE4eOTt9l6NaWmkfTbGrpBUzLS5TpCjtzUGdpfsbkCC2saN0VWMBfB1aTCpZyaXr0f88j0Wsv6slVdX1UrC52lyg04+hBfyYySmXWb+PBaZa0bodBybu7jNNCfQGKiGTkZmOyIFTKdFpRwE72xJ4eJxXKrhPStLh0UvtRySBuX+2U41AqTF3c7IfgaNlVqnFaNx04EbR3uDowh5w+G7W0nAzbUv7E5i7ZzCBqLuFrh0f/UVSOAh/+0HWEIkzZOVFnAMi1Lua+5sLe1kgURidG+9xdR4Y+69WGxbdrwWreFoMbeiflBRzZP+H5Tq/zis3PujwnDkTHlzWar/RQqYURFwsHYKst86bs+7swVGyulkGCmeAARAOt9cX4pYGjA6vrjCWU5xGlg9ufnFgIgBG1Sa9nUI7kvuRP80Puugj3mOueaTbn9TOGob2f0lsn380c82591RFoV8hX6m+7EZ5/LNb9mLLR9m57V3BF4chVmpis+0ZVq1BFkF3M31XFVfsmxlIVe6HU/TA/bpNjfpms09ShqpojxWSdzXVUvFanT+2yVHOsKlnf9R4pUx6SBi0TOsMI90LtfZ++u0f8bxk3vTS1EmdPOER1zwy+G3biXMY6K/tm5cWNzqrxRo/81eImPQO4Jl6sZHCgZcPGWh77V14vzxgGrWJNl2nHiWhT7SxX1MPF+y5PhCxQsbhtynS8aT033fWNUuYIrEILB8BwaeySLGBw28wV5iBrXZai6VaTLHicsjXqVfMhFOaTUYNEJlgpRpCtVl+qONcxPjm4mdAh4c/24EU0p2Tl2JIMvAQUXbXjIsT50eEeAeRclbpYTF8VEpHJxZmflK2YNuNZxThOBeOaoYsWUuOC6cpd3MpKP1eTjLi2XlVzBrT0g8eCs0+0F/kbDkGrOLcr9oOWkjXvy7iFBg8lSA7WckBGZF040qPfC4Tj1uN7NOGhDIh/MmF2wo05goNyNJq5eNl6x//DPXnMOBqYz40fUfaJ8zaGblSoUjNtNyrNLg+les96vPfn0620/ulpK13ny1UuzaEIAxNBErmiHKZs6OMjS/bXye3VLpUa+IX7XKtA0BIzS5i3i8PEwZi8S7LVuE6Qyj2jHFfGVE56BtnTWIhte4UihyhuPNE9n5Nf8qUu8WOdhX/tfbY1cKdURsalgSa+pXchCtUFSKlmPjM4yuhU3PqtWU3BSkZIKpVbRsfRQU6+RaFy8e5c35E5Q+wrW29PT4VAcG6Mt++kbNFPTahRvFypXIEZKN7yGx2miLmkIXwt1XhXJbRweVE5y3A4YwDyXndXhnzyU3PZbSV904X4Eu9f0XBHoYqlO/L1ZMzkRDCt85Jrw6f5jnxokqkThXVKp0G/bc7FAazSoSAFPKtiLZpK+UrFXSvo73BOv1V4o0Dr7VJaDflCTIh4Nx2hA47p7DvXLzajv31/9LaKAvjuAi65S52oIVOyYs7wo8kdUFwgpWma8qwL2wN6UQhc1iN80xRp+7Q0tKZy8jitJNb4gjHNV1gHBuj/4NtAxhLSUpWyK5hrBNTsE6xkzqfUtIgFc8POsaTe7jnnOBVjs+sF8YQ2Btm1FcqpuidLDh/3v9LTKh6NIp54LL9h2wo84L/6ok3WC4nHSYFOD4n40jjtKUktKViqEda0jmHLhVy/alcw+Bf6NmYL/ZkD9vQNu/AO36jzHRpwaO86sNNLo5HkISJWl9/xK7AUvaoWAWXshgRAgKFecgg6P5J3Kk1HiU1KfDoPWJOVGixHBr72BSeAom3PnDyIgcFXXgYNksAwR8+iilrElogc54lhAjPeAi9ETREyYq8Tt4MFiGtx3Q7a+GPSvy2gNv23jlUJaoHFjP4gCInBqkga9dC3LQd4yx8JYQmwbNMw1OjWMnkQkVgGJLUWseNG7XJ5YyUQd3pV7or2/zvu8uMcjFp5+1kPE8QcqYsGyiumwNWy/jic7Gz0j4pjBdFnlXKnktB80tcYM+TRY+RvGWmRE8UHz8ikS9yy4krk+FjICGUE/VF0pO1RTInQBTOmGpo/ao3GqAqTLGqewIddKNek1l7fsCbSEPT5McW9W4mRKqoxmdNF4356+nABqV/wSFgdhXgwVzCw00YxhYeEhxHe1PugOgByhHmqMSkkYSEY1h7dUWjEcrQQ2SQAeiBXkpvkgEbqLc8zhsz1znGzcqteRxmubg2gqU+3Fuu+U2hVEiBADk2auDwfmPW9F6tecl/i7Eqdg5LkcEV8ATRf5e0vyByviKcMyMKViEqNLHSSlRD/8q/weajuvdRRXUUKfikltGALtDIe45wjBfdHJT+OMplECFGnn/irp3g5KgHm+EQFy540DoPTYRxJ3en/QLPUEYEfwBmD+nQdEJNxb94CANuENOoJfGK/p8vZtLDzxwcqAYbDkLvPDINXt/5nfwaA1UglFAFBZjdjm6yoirkIy6/Jyp/Nn423I7SXklGyJ/yVAg5s1WTBcJddXo9VlFmnZPVmImweu3bZ4enrF68x5Mdz2bca9bgctus7lMr5EKzTqarphA8OeRl5S1nyDmdZ0eRGgMeXOuXieybz5qhRqedYT634L3Gg4VmMBsgvH7YKtYcRfGJgPGUIso7mgqkaVFfpI/zHGJ0YJi8SI0JmV34aBHMSaV0goOp6IEEhMmtIJuc9YRbAcLXZQiGjCTfB9iU52qDp+z6HssJSfPOVrQk/Ln0zaR3V8f6mzVTvSwGnKZQ866t4vIK2vdBc6gVxFrmcv/S1IQwBbqHypYFtrNHPBDzIyUaSKRO1xzs1VZPbZae/Bzz4lQZdS5NjWZOBaDeYaHcHr6WDxov2RtzOlC6H6YnNyyCDshmWoNzD16r0rw/uQx34yJM4/uL7s1ulZPtO5qcHAirW8MGKPvIoI4gW5BIAguS7WMhLLvCBCMnI2JsqjQTU62Y1GkU7h173MsaaFo/r8jrB957KTYaYk0opJdbH4aI6225LOWDi8MN1eXkZisdkgzdlgOaBW13kslZMSr3tEqLijtZbI5EZPYs1kczj9usa3YeTTMKxQm466tRqvW8grNRrE19D0wzzRCHTSOiRYGB7ZYsSaQT4ZPumIt0cRz5OQsY1hLXaNdMIxqWigcv5pzc4O+6F5NSMLllikWGLvl9kvRfzMJm2dD5/8ZuG1arK5SUYrpKKQri1FONX0yOs/zS4RLZ0LHnc19wov9hxDmLc1Zs4Gy81lFpxYG5EiqkAOv9N+Zvg2ovDgmxKj2TKe+bv2/3imM4w5ZaWJhFyohcZfCNFUUqlHpRNhPjbLmjseh6ZZmjL46eO89j3SJZQayne8G2crYc/PaN0gCssOOYyQAAWOJeQ0GKhIbbIGBKycIWB40y9b2iDOWv9g1GR5R4D8g7kFKnbW/cVgqLFYw/YIVMyYLQ0BZFLIcM+HQFIagbWXH3A/wJS8i2OPWKH78tABQnuoGRd1Rtvi08EDY0avwZOUGh0J4qdjxPNXiYOY4/ujpE4faYvCWADQsBDMk1rBjwUapjnk+DWqqjP6GhXDJTNa+rEb8Hu/7Ol8lN2vqv/X9H5FnpZ4T1Wjid3kSz7XvoJoiqVmyNTha2sO1df86jWnuh9EkXPw+8+ATudFUqzmRc8X36D15eicGzVn/P7OTB6IenG022aYrYa5XQztIVB8z4NpDPT1RxM/36jr5HqVH3WfEbvQWdQEJm+YZvc1GWrOgfDxSYsziSRZTDZmBN0lZ/tgWGn+INk09LAbHYs+7sVcK3jS31fuiT4O+00snYq28hTLpDybk0mRha//ag/fEPpLC3zBazsy/OL5paR9MP31E/3ZWd7x/U0CnyEoB857jwzkaFAp/oE3FRBfwMuISYN99fMNO4eBxJ0Yjq/+6gWK4vkEenjRsfYFrz5OH9/l7HCztOh++wVDhQHXG3QsY3bkNPU884zvlEGQCX1uzytqO0GpNNLoXBW6Ca14oKaGAlG1IjPKCdDxQKVac9CW5d/yzrlqjWrUDyKCiwEalfIAnwgI/W4qpfqkTEmEnC4nOCWFKbjn7bhEiMDZIeEkhya63JQ7QgRgfyHWXhGcZGlELQmAyN4uZitDkh0mwh00vCvUR5MnohKDiqWoaFONoO0pobhQ8CoqQslXFlsTl0HSkLVka1I5LX1AiprSFTC8Y6gIsSBMFTxPra5XVaoK1fNychEirNJsheywE3Jz83JoOXm5mA5U1QKqiZpSTkCIgEjpRuHyMggVUOR58bu/NMlGLZJQiNVkhhNQH5EzET5GbYcNgLw09oXsBBUaURKA0s7bJAWC4MhNIzKLWLMAYJcyhauMosos/GOLMotoCDWApcgqJycvB0akS7xNw3vkZueEc0yI3VMLC0h0zDWry8uBwdBFoA/xzybZVuPTVr0uVP1ipDwKqvE6RQk4ZilQKo9aV8dGIxoNlDorUmzag8TpXop7UneSZ3D/WnriEVFB/1afmpoXr9LTsOikyQ8PRYYUq1HBZixgVFxagfwNvZEt5vHt5bLy5gRSQhibpUYH+/5JcRkMFnzrYY+DtUCLgwdf9aKJ4JhrxiWcbK1ZlyJpfjQuDyw7COu1ypvQYyA8f+gNHy9mc/YTBPdLmwVzAZv2t4EA6IbiY3HgnIllGSffDbC4g46u3nsQtLBuYVwWb5u37KmpgkGrKPFJFeY5O3c7bqX3hXBDxno09GpqO9H1awAy/McfwzUDefMHZlhlb96wPH5F3DciyU81vQLMmr3usSjalW7p0YNcvoSsBzXtKRCvGLxeusitLKaxe0NsxJCvt4ImMTVBPCBPfm/ZPv/WF11429WGhNj4WMNqW3xXqpopotCt6BQRCiVp1p70zPNGAdnbZg7oXTY2+ByWtDZ4bXQRVhvq3GrMaxqF0pZr45NUQN0A7Z9sQDZQaZRrHlOQBxVYA+rygh6oo8UFahMDaXXDlbWUOVQa75tnuxEQ5Pm41mutdG2Db4+0+j8CWo6Z8pggsdN1UKP7fmhd/kmHQadylPBNkAxmmyl0irYfkHfjOa7TqXBanEoHy/c9vVRB0QFc5mlFFLVFEVAkqMqFU1u7sVuR+o3tOSAb2qzHVB22TrNIx+vkH/TCpWJjs10hMdKwrT0fxIK2BFtpev3CutKd80KC4hvmwaniLKsv0IpCKJA1RAkRSSAmku4kaWu5Drbaof1CX2E/ymMSf6NZmIudElpAAty0fXtTCbAhPnOgSGgR26fbN/cw80MNsgdYl2w/4AV9v75xYlybtDeW9LDyuZdemJKsuBbVgytrMaYNcP/Obw1Q9uJF2XA2tHgxRPeZixZnIvhM08bFIWJRf1rbeQWtl7i+5x4RxeVXVlTNeTk4s/nsDUWNHJYB5d6LW068Qxh1PeIySriDbz6rroQV3bO5v0GqThPbpKk3H9D9I1mLpIf2ocMnkvAVwGDWiEo+gcHECjKdjJbX1Yks+xsZOoR+oxXQjtDV1DvAgXYCdezf2IP9HwjrGNd81gp8oRmk55JuIKHuBumBlx8520WBRWJJ6E5GW1NEcBflX3LG2kZ4xw64hEYDEEGLAAK+YCEYMBj2dL4EgB52psPsyzZ2nC22DybdjM2s4Z6NZ7Z0N368QiNm/DytILo88ILBvB5JUlzrzq0sqgZX1SIl2781rb84G+IzOAyH+WoNXzze/iryRG1E4QSXRzI99wuPEq1eDPQmYoeEttUVoh4Eve54DGec2bI/lJXf0gOCcukQMIseHaLRGLTZcI5juq0gj6QTwGumMhzdskKGJkbZihXfvnD2EO71SIKs9NW96SGc/1hFwlfDHkNqs3+5gdx/WerTToNFxUsdkgbGX6LMJDh+DJmgMXDyuOhTSBIDfXnGspBCJw9j+3BZ2P24IQrfCCbplCH4KZoJ0HfwMJlOzn6OKC1YpQWgD81ftqWMyXzHLHSh4/8GpC1fm2KNPUecvZKV0MyyoAWnY/lzlFBlOaRwRWLs0/Tfe5ZUsVwjlS8SD32I9xGnBKiOFJSBrSbvf8VtkIUzLsi1JDiqsiuGEhERHbXOPtIucm1UVAQTjqE0LUWiAtP1IOjW2yRbinM9vBoFoKNrhCgCuyMT56+6WzH+xn1q/7Q0DweJ2a0py838wpUJ4AVQkf0IQakI7JjMoIjItmQmn7xVlzNJ59IpOZRKTxgfb2QZJ/O5/D8OmA04/6l7k4kZEIw4jwj2wWOgWyzSjBTGHVABNUqnqvEpgBLkXeJUv/wg23L0ISG9nKJ8jXHl4azToXFdTDyz0akUf87jb7CPA28EOEAOJOvuqNVdnN6K3m4P2nKJx4hgVDAoGBgEOR2ArFHBCJi1IfdmZ+t577krKioyqpc8Q5GAAnAfG/LJWgqdy6BoCUcY3HSVunds289JgZA2FEFVUd48LCAp9Q+d69dwoP9bxA5IlP3wdzZAv/m56OedTKEQvKczyA4GbW42bJ9s+kU4VaUYq6Oovw9iWDig5FalbtszElNmKHwuUFEy2UrKM/LkrvAznArcwoBZ8Jk6C1V8mp36DGY//u/VTll8tpjSViTC9ObTic7TZIiMlSUqsWMFORBZ4CA1myQCUdjHj7PcZswcpQIS1GWrnZoz/ceY+jFKXgICuUGWCmnNTrJqxK3opFXHBt04aqxeCxCS87Y3bJd813rRRuc/1+691s4We1fqEs8Rlz7pIFI3Nzo3N0uNR3jvAXjxQIj4j/WiG/mNPslmh4mtJ99Q388dwjqyHU0PhdmgzLdg2PodBL2zHgZ3Px4mHo9EOjgbojDg2axXqp3Xj/eeafZeZfCqVXAZzz19NFjE2O212zZUcssliQqXrVq1TMqG958jz7q+fGVwkth9r/+vbcfhkCSotAxKdHtyLiikgIEPvB4UJrMLJ0NJpaVJkL2YvXfpUgPHjq3v6BCn8D3Il5Dd0wZ4BKBIyGnk20PMjpTUTckByUI+Q/STs2fBRhJW8a1Bxhk1/ecBph+z49vDxofnZ5BUunszaBBwcdD87FvH6GYctTL7vvLTCHm3QJOySeF/vP3XyL2yudHNIALpfHhkByLU6IZPq3V0B4zQDgUGZvp6nwqTHUSNdBJe7m5+2t+roLcvpsuI6b8P+hsVBYt8jD7LnCt6CkTpLlv0mLjckyR9lUKpqVAJUgMQQaC4oIKQUNOkQipDaCYnhiRGRpqYpJwIP5LPVpInRx8T92wOodz/PAa+cDS3Ue8satWzSUV60K0BBMdCBXQvegHEzG0eawz0ArsC2zLZJ10NVddAJagspoaQoNqIXo9SNCO0GzSk2VVlAD9Jpj0SyRjwvYA0EzKcSfwf4GzcE8ZK/JsvQdXkyzbqKpwWA1WTLoMFbRdGblAhHqCKUBHsSkoFPBpVKqLQeEkoAVZmisrAFlrGr0pCbO3ANmSnk8GqqDH3RB4G4rGjT8FrMvDfnwdEHFdwf99ahLOhfW4MBdvK50WazEjRZFObaH8Tnkf0kfwEx9A3Gfw1Q8hiqGZn7mkg1J8GVBMl6jxmsLRt7Q0Pjd2WQrqM9i9Dbev5vlwD24vdy3hsr6WXmJI6N++bJI1uFyAVjeNpIoOr00llSfdEZaJSaZmVnHePJ7cy888l2/FsyaZkW54dOdff7FwOMKsIkG75jFVBWUuWZJUAGWI2rHLLl4CiKctHarxo84nFBVzW80vWpKbZFDPSSfxnQZwzE7+c4NiKMEHvaiauy4nhZG1g27F7w3wMXDCu25aDFkW6bYPSNhAPdx492lkCbAgLiJe2/a9Yv7keIjtAaeGQ2uuUli0EQoRTX3SyQCmy4+FDWyqIFNPXxYCqGY9LNQn2DTbxhM4de2O63Uh0OFHvQ/KaK2KoeSq5wx5n1myjzjg+DqoGxn4hQUQQ9sOOnCzHPiDAC4SEwvUmxWK+En32SoS3ttp4ScGKRz2LTVa2Ew0pBuLCzM3m055ybkWA714bkeNCSJ6ZKYeEWBFIvlDAF18qYm/vTLnKbmfNE5gHc8IEYLHlNQHCijr+8dP96F1ZnwFnieOlTzcWiEUb2QTLqSVOAdbKvC6BDT9efNydZb+N37yZ5qRwEbpxAVA/eQmZz0HJGekavaUtp3cjzehl21rq6Y0MCo1DpxTLiydpHNpkMYdE49LInBIjykGNy9sOh3HTuJXG6iYGz9rkNCQSJfp8yPGYm+DF89qXF3HXblW12q2h5z3YuKKy73SBxnij4CfVpj4vQd6ga4nZ2ZzzOcwLyXuT1zjUJSj4sEKyeUaSePFXGzExqn6Be2R8UJX9mkqbvpD4dra3v0vDL6ts3mu1ezz+/+6muv0wmTjNmiImmeGnzKYIZgrCFGuaoPBVrP4wX6RcWsd8z6pbuB77jlUgRtza1/1JvsBn+IVHjLsaI8XhnCxkMX9hD/C3x8Zy2LFx29fExbFNrP/CKmQgG25uhtJV1KhyhoNS+QhGCkHyjAw5FA5BoQLxegLfKc/nX9Kf3H/sVHqCQ9Ghq1Rbnhf1rilbk7wR5TRLLulPbbxwSrv+eNPxd+01OPJcrqVF4UXuj+Qe4Pv8hBrz12lu4hUH5dBb/7fLvdlD0RnuX5gCfYcwwQQ9E5a4l3t/f6qYljTc3TQm2JwxSRCC45kf3vpwtiyPCpgbMNCV22HqQ3XFFvPk9LXhq+Sr1qYnPyuk5jTH2SsPHNIDLAdv8DJPl7dQriLgw1XLvwrLt7AgjJQPaP9C53VqPxpjtadrL+L9UsIYc4wgmu1aHV2zs/mMGwz1rOh4QrQwGs7JJIyyRgnMFvAZrK3bzkNjFneu+V78zV91JG9raLfCZugrM9ot1THjRU8CvMDB+F6QFhu6a32zb7on7Tsvi64DHABwTO1k7cTo5TA5vWECA9cQ5tOrY7BBy9+9nK7SEj35MofZR3Jyurjds84CWwYS/EJoPvAdEsnlZqwcKk5SMCZgeYR7KDPPKXu+DyqSR0K/fR9JVgx9p+x5/pySl215FIrBH9Q9MzO/UvZQns9geFBcA0E1uvnWA9bzKV0z82e6KFkOH2n9kyeP396c2LTl5s3kcC4omLwFrg6mlKWUOpUBFUgpCXyhaPWzTt+klnfv/vN1m1M/yKd/xZg7/CO18MUi32j12MsCjOCoYEoA/FqX4j9ZLrH8hB/Bfar8bN/7MuFz5SdcJLaPNoATQuHg06ZNn0A4tAbI6Wq6HIwDGDf4cQAHg5HAkhvifdgSXGXRlWgNdEMDgA18oaQkTpm/Tuu8pSROm7zGPC13w3ZhX5t2aVO0XaavkZd7wJqzyrlve0zn89hO+/PJLkxCIsj1KeaE0uyzmLKZxqB9QCbAxO8ZUL39Hw/grq2Z9ucr9gdRjL9cG18p97u0fAiGmbLmU3Cz+7dPf0MiEVhsb7Q3O2HUmu0ZVgXAhZs/mxlV/ghlnx6yj24VbF6yWqFa/k5QnfZzzMEr7wK/X7H8iF0MT6N/o9Nw5+MSrJ7SpU1L3cGIehvbCzzpxavxUFqRXsP2iMAErMniVq8HuXgyHaL0m/XTWli+kE+qA2kDOTK4QDkjSceJPj6pblRrarBlMJXXPXkSNYxComcQlYLLxwZZwhewAPvgWXLpN/+m4Hqx9qOg1U33tKOD2WGx7yLUhTPQDDh4keFQE2sh9dISx1q0PutBhW+V8EVYRH7Ug2M6gNuPnY+VASWu/KbUtuu7gAyxAbmKDPCARN+Zmtpp0ZmW1tqabhosIIb73AL/KPf1FqMt69x72upe3YGP5i/QcyZNJudQuJEzVf9050ga7QUtDcmroBKmV79ePWU2TXhNmNYTNhJr018pq/DThFWEabOp1av6bwC/c+v2Ty87aPzdeHDZ9H6PWes3ZNb+X48fWRrTAKie/h+jHvptLCTtyvL3wQnU36nZbu+XXwX10N5EqKQkekMTtk1QUsJzhcLaOuXn0A6+LvLDUrCe8fnrS4kRLlhAUVCab5zes0gJqcHAfQjzXoozfNR8BIMj3dXdp6pPdVd5fNyRuG6X/66dKWDbJ/rP0K515J3prwwxnNeencxI88gadQyIgaxXzSKYkV6dr/MdluzGl/qTavt7G0zw+O35zvMg4ZMijAk+yiQ7PxqJzsuJAurdeTlIVHRWgVkExI+9fPqGXgpGB4XAJ7HCUsOvphbj1W7nhI7pERHpjkK5cKILHa9/4Tk3vLqEduFoLHrfmppvT3KmFDYtZ7I6XW3ipuNQN7lrPHoDjXftYl522IpXePNFV1atBNu+jrtqtheQZcejV0qsLt4BDLV9booDA9oZxxu2RBJMD8fEmDRgiaZdpgzT1g+t16JlNyViG0xjYhM7QcZOEKoNJJL+8tHHIe9R8TtV+iYnKHec3iebRDRYCi0Tzq9DLl9GENYZgEje52Anlx4CB6z9+bpd4tysdAfQdNpbvjM5F+xEHt9ENgFN3DqpFzWPwXL6J18rYcee4ifeqSlOUf/vWJsNor6aPFvRZxtLsA4X5UpFFFeb2L7ij7kSTbAtLajdJhkkgTZeCE2SHtqj8zAuLORGYgnvZtDE4eNoOAVyUG/dkhHsfjbVhkG1V/pl0C7vInDaiIqM4+zVB4fdSslpl+wH/NbUd3fDSCX+BgFN73jnbr2ea9DmdLHpVb2xsTExvWw+55A/dHpGssMah/iPFxzi7u57uGd1D0j4cgA/gB/CD2bc6CLgRn/IF/22iK8jAtKbRXL8KO4UAYwRvHzRGxKVpONfpfJm5PT8uNGkAyzWkBmr+9JsiAX2HtNiFhdgM/Crom2txEw4ktgqOOFHa9RKljMvsfSOXU5djvo8Zr29Y6+jIXfAH1Qra68imvKWKHYE+d4R38QMx6ICcRxlOYdhZbkamy3KNDAVqcAXyI0coY+QA5Lff4ckEhqaFIJDUZrbhDTOt/4l/d84pETPpIXtZktP3Ltu4566/nPWDnmmLD4Aw1E7w1CJWcw/+Xorh8QFC3omixAOBusUTbjOdnOJiVxAn1vA54/sDHCcmLs1bxPPQsXEPyFEO2FNTGCZaw8BLDB3Dg8AN63tvmP8lb52WymPI/5/ejBi6+ybvhIaRPyovUUM8iNSLYlEv2DSpMVHUnAoTCJbUp/cdgsK0F0vN493kvvPWRQkdZ9cW/l+QbXYVAzM19493iaRIZKCFdqgOOCWeXmkIceMQJedym9ZapW40SelzjG7gOfm9OqNS3w43bwR3dXkxwkMIctK3dnp/tfAQzuYn4bH2VmQZOTwud/ouzgtXtV8vUCgXGcx14OG9gdGWnZlQ2lWaxU0EUXk84GdtAL/Ewz3CeKFVBkp3KxKYIf/QhP+szqKY1uQxVTSldFSWqiEv3KLhz/rM201IMtcTQXHkWhb5eVXr1fMqZjrYWKCrG6FAB8Ra2W2Hnd/pxE+sVRy8sVAaUdthA+r3kuEwi0QdOTEnZVwyNlwpEpu2rWS0LnSP23Dm6s5v7Ze29R/9gsGvhdxUWkiNBg+n1m9LlcedSqz5Mm7SqEYhyAHHJKX7goQ8Np+04y1iqPeZOHu9SPpQWHl8bj820evHG+zMDPRO/4v5MX28PhcMxxlnsPL40YwIqhKxuteqJtx1LxzPmbI5qnX+psXrJn3aZiAD+IMJ8FV93+h1/kvhqf9HQNVJ6lgoPnFSRmXlk90rMBKNWz6mOg9/HbYm9gPXT42HVYB3/OWR3RXhFf+px1rM8HlLUvV4iRPzjtG+39SOKkbnWxmj7ErZu6CV3jij7T0NCA5ik6jgD8qHQWgmegCtFEI0EYkIzQAjV5evAKowNTHfPq812DD9A0qwSMDIhjUegL07EOvzfUgUMd/P5y9WQE6Zh99IekR0Zv3yEpm9YiU/H9i/Qz1+kBlZaGosOJ1oo7SfZmL5DEDrkZMVXuijCLLF05FvmHxiOdNfEQSGh8NS3mPiMrtjykkeNLhx8MUlxckYMQ99hnREhpCgxGc31yFWdCuHgdHiTzEk8GX3G7mxpgHNr/42HlDNf1y/iMMimIeSUHRbQStVOMndIC5lrEfDWE+ZL64PQmJRQD3Ne1af4O6PrsKAEV0nZLQI0hmmDpfSiQnDBl4wo1kG6pK+6RoTnX2/BVfrx9ML3S9IOKVCIqubRVNi7krP2QPqpf92RtaXy0Fr2rTyYADyNU+5jb2GgEbGM+P52pGlj/zbQw2udn3GQsbPaX4f1An8vHu7ZPVF0u7hMPe74Uk8JLmK8I9eIWPw+pxUmwDqeHNcN09n8EN4NzlMRUijtirdYMNLjq6qgWXOJv1bV7i0JPnv9o5ZX4uGgSoRMJgjB2hNKkEhtOBb+vy4Y4OaB6U3zS/QGwE58PzkudtiISys6ESIgCAEUKIZMAYX3Z+6EiJPywKsC+0lwScS41vqOup21OsLFHuAUHG4Ian4Yb3hvCx6nX6tMGvRd8gawC3UsfAWP2Id723vzRvbHDMoq3Q284bLy0ZU43V07wnvIEIBJ+3jBYxmxLoCbJ1c/OCaMIjJUu7doTHFc4+riNZIASkjY2O+dXUC70PA+6Hh2/qe3/tem1tUVNDQ3j4bO2CffsCLm7vJRIM/f0GDrfXpYMi5HnxXmtAj15w/HZZxof6v2WBgJH3/bp2pk42c3N2YkyoJsInRNfSq4tONlce3h8k8DM4HVZtsadtAbPx5zEIBnMOcx5BzmOQgJQrHDM7x5xlls2Ejyj3IFPTmD2Y3eZ5DwLUdJV46glLRVdTMXump3P/awhvMJQzQKhR+NQ3CtjRp0oewGZBixZBS8hcRhacCaOxmVAWO3OBGKjUkAgSq1Ti3fKpVUAMRGr1z322E7bTXQaZAWRGnin4ekoe0dGeObuH808XDndHRHR0hEec/FbwUyXta9AIUFyIcLGP1GDjk7rra/KS97L3r8J/is60tDE/2796r3q/I/n/XenjhKNfpb/3ovzwSvZTTLr3R3L4LVii+tAs/XqU09MbJNSwTSPSqMPeiT5EfYjOdZgFwcYlnT86vYUjs3WzyrE+Wd+0tF5WP23YFze8bkHQ5H9NXk3CnPef93++Vrhz96JFHwYHd+5YtozKL31seXJP5YLgCvcVNW9Dyip9zjpHO/zyAwT0ZzU0jIU3fPjQEO4dODv5ZgOKxu3tx01NXr5ctne+2enT7e0sB/ib41xVJAt8lfI+JVBWFESRtclKjP8N/3dEG7nMLXGnpVS8V3g/Xdf/7P2pgV3Nh1yuvx+lyybqu1QyVUOW3tZWZgtmM69iKBTM1YkathE0H2lnzRDm1SsMwtACEMm9iIrPbV1pL5OAEN7WygH6AG4rLothc4tg43yEz2qoI32cqqbn0VSgG6joD/WgTl9kseZYV0WjnR2Imfby83HkTicGa4ycRF9NTyK3w98BhfIaXo0e/6Am1jPOk48TJ+P1FbwK+TxqEhlYtq8lTptPE7cQCpTKOlYBqGfV50cQnI+807kZHhiAS2g2ABF0Kl3j/wDCS7a9Fz3xdk612Av+co6vzA63PxZbgl/fqY6j4UnUzuSsCryo1i5CRIv1Nnew3V/Zfv08mfZqKKzwxQ07X1NhpCsz0qE3SeJYvjHNJNDce7JGm4uGcvcFvC5hPsze6P3FtzHbReTMDZP+6funMMxXPNdjDn6IcQA3xwU/xjiJd5F4cwe+F+DneED4a/Qb4GtbAlSdS46VLSmNiwByUBbXzLSjxFTnRH8v/PvErJlPh1Ir8WswVRBDAdens1mM1YzcLOo/d6mKxTmp2Nh4Cr3Oro5OCYmJMy1PooULf7qcIENpAKaDuRR5XIBt+FkY0sKCiC/qJgvhOscWd/EeCIEYLWf+m9R6DLCyGKlw9HtHTRaUBi0tZ6kh1nUW8PHq2Wt9y8zvmx+z6q//mJ203QwDI+ObokvlqhK4zN44O3j+kXcV4ZYcCNnyfNAJ3HdB/N3RSdF9fAPwWsT5wXP7PTNLstBO4pXiVuubmc5SUL2SO+h/1i0U+xo3Wx6y5Vp2NZdxiB258+KYZSllJmLoHJvdvSC0Sgiaf8w6/UoX9Udt9vQFgDz1AuEDkGeMiD0vuYSgAaN+RMSLjztGh/D008RZYfAbaemMLo9OHNcMBS2Jd8YRpql0Hot/FszKdh4JA4DSAj2XXXI7AnHprGt0HCSxjv8I/ET+BUN+QeTnukGgY4sih2BLYrKfHAvlLPwJth62C8mlJ1yUiiDa8I8A8YIigJXVZ0XEQl2GgsIzAOSbp+UjmSX/egoEByXx8Pttf7cJsZKXmoTJBB1shBANYbRgYye54jjipzRjEgT0LPgu9TfC5/wG+C9/N/xUboNs8xAcAHlNiliUtNvwd9BnkY2rZOvDNiDxlat8xFTynwmpVJet8CaMEfDLidXwC+yCG/5t8GjJIviHuS9JSCwk3juJMBbVfwix1O/Dv4u+9TtJl1qkZusLxpDgrX/yFMna2hCAxOm73Vr1VJeFXdEPmcDUb3irS4+LfBJt4Thr60l/I65b7/AKKdz6F/8i+MQafUiFjGCTVVywfmIkfPmfrTKDo+tKTDY1+C8cEQPYZXYma7fxquhyiojVHB8GI2JDwP9aZRmMWCwYhTthKP/ZtU7/AUY8w0z/meScbvAv/eUqL+Fnozk0yWalo14H4J+5Js/6R+QF7RKabBYFerB4gT4ce74rcgsMIPIODMIJC4xy9fLEY5iiNaj7D9jlVykAofkdgFGMBxA0f3hM0d+ACXP/A6ZoTYBA3ZguiRzbPpNGhIS67qaalLCJ49OZP/dXtNlBjIf5Vj8xjjStbqbzyZNfkDFiOIyvtk3J1CaKr59LS4bOSR2iDKjSQ59S+PI4+ydbgQclfnFGKkIgQVqtM432SRTBzKUnZ4mP/ytkZQ6IGS229/kTikZ0x2uNB08a/IvEWi26Yh+9slqJmEbNVOcUXu2ZaMh5CVEL8mwDpCQPegMz+OKRtGd0pQf7sj+uSLa+Vln+nw2GYOzMZwETLGTyG/nwlWvKvtTcy4yMjbO5fKFYKldcUq3VG81Wu9Md/d4fDEfjyXQ2XyxX6812tz8cT+fL9Xa9n0EilYXLH/UWOio6JjYuPiExSZGsfNOeUZOSmpaecR/TT9nanNy8efkFhUXFBjgsBiOazHrTi8dqmNGQcxsn6lhkHme4NJGQNWgtHb8TElUH3aSI/VqFQQ8ON8PEyk+FT++PQhNwyHdjD2xVn4FzcAL683t0BHIitipcuWO2GrgwlmOmymI8S5bmzFGegFGC4czbEcRDiQVl4DtCNshnVZIn1AmGlWcnskQSQSLsEDhwU9oG8fM5i31iOxRp5YlczDLQhRfGqYOClVYxz5USH3LCeK5EoiaGhOMWOcGqDKLuQB3P/VQMh6HXtxUBJTjcFrSniDcpAo+gEgkfpmlcGeI50AlcHIwltjyYjYEuXytxDhVTzkSHUkkOwuOlFpU9IR/WuQikUo4Yg/UJzRN5l8hPRG9WFSCL83LQJiwWNJkHWmmzDtoM+Jbfz/xuh5rSfQ5z/aYPGxCboa9dtH0xSh6zbANMs9meevK2qESbSmFbuC985/S+mubp4MTKWuv7DRUb6mste88O9xsQG/C17L1vMSJXI8hEJbncEnou+yxa2BYpBwK+fNsBbWwTDQSyefGOJFebjjY7wAyce6oSRFAZVnZqhxwvsq3ZnjKeqDQHQ4Ov5x5fmSFbZGVzLXy/GYjN0Nf69nnehVN/PJASrmbT+eoCAAAA') format('woff2');
		/* iOS 4.1- */
	}

	.iconfont {
		font-family: "iconfont" !important;
		font-size: 16px;
		font-style: normal;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}

	/* @font-face {
		font-family: yticon;
		font-weight: normal;
		font-style: normal;
		src: url('/static/yzy.ttf') format('truetype');
	} */

	.yticon {
		font-family: "yticon" !important;
		font-size: 16px;
		font-style: normal;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}

	.icon-alipay:before {
		content: "\e636";
	}

	/* 	.icon-wxpay:before {
		content: "\e607";
	} */

	.cztop {
		position: relative;
	}

	.czxx {
		font-size: 32upx;
		color: #3a3a3a;
		font-family: iconfont;
		line-height: 100rpx;
		height: 100rpx;
		background: #fbfbfb;
		text-align: center;
		font-weight: bold;
	}

	.czyebox {
		padding: 20upx 50upx;
	}

	.czyebox>view:first-child {
		font-size: 32upx;
		color: #3a3a3a;
		line-height: 50px;
	}

	.czye {
		width: 100%;
		border-bottom: 1upx solid #e5e5e5;
		font-size: 29px;
		font-weight: bold;
		color: #3a3a3a;
		position: relative;
		padding-left: 20px;
		height: 40px;
		line-height: 40px;
	}

	.czye:after {
		position: absolute;
		top: -2px;
		left: 0;
		content: '￥';
		color: #3a3a3a;
		font-size: 18px;
	}

	.onstep {
		margin-top: 40upx;
		/* background: $app-primary-color; */
		background-color: #ff5454;
	}

	.czmain {
		width: 94%;
		margin: 0 auto;
		overflow: hidden;
		background: #fff;
		border-radius: 16upx;
		padding-bottom: 20px;
		-webkit-box-shadow: 0 0 20px rgba(0, 0, 0, 0.08);
		box-shadow: 0 0 20px rgba(0, 0, 0, 0.08);
	}

	.icon-alipay {
		padding-bottom: 20upx;
	}

	.icon-alipay>view:first-child {
		margin-top: 10px;
		font-size: 32upx;
		padding-left: 0upx;
		color: #3a3a3a;
		font-family: iconfont;
		position: relative;
		line-height: 30px;
	}

	.icon-alipay:before {
		content: "\e636";
		margin-top: 35upx;
		margin-right: 10upx;
		color: #007AFF;
	}

	.icon-wxpay {
		background: #fbfbfb;
		padding-bottom: 20upx;
	}

	.icon-wxpay>view:first-child {
		margin-top: 10px;
		font-size: 32upx;
		padding-left: 0upx;
		color: #3a3a3a;
		font-family: iconfont;
		position: relative;
		line-height: 30px;
	}

	.icon-wxpay:before {
		content: "\e607";
		margin-top: 35upx;
		margin-right: 10upx;
		color: #007AFF;
	}


	.cztype>view:first-child:after {
		position: absolute;
		content: "\e66c";
		top: 0;
		left: 0;
		font-size: 26px;
		color: #05c160;
	}


	.rmbLogo {
		font-size: 40upx;
	}

	button {
		background-color: #007aff;
		color: #ffffff;
	}

	.uni-h1.uni-center {
		display: flex;
		flex-direction: row;
		justify-content: center;
		align-items: flex-end;
	}

	.ipaPayBtn {
		margin-top: 30upx;
	}
</style>
